/*
* Copyright (c) 2016, Freescale Semiconductor, Inc.
 * Copyright 2016-2017 NXP
* All rights reserved.
*
* 
* SPDX-License-Identifier: BSD-3-Clause
*/

#define ENABLE_OM40006_ACCEL 1

/*******************************************************************************
 * Includes
 ******************************************************************************/

#include "lwip/opt.h"

#if LWIP_IPV4 && LWIP_RAW

#include "mqtt.h"
#include "lwip/timeouts.h"
#include "lwip/init.h"
#include "lwip/dns.h"   	/* dns functions */
#include "lwip/dhcp.h"		/* dhcp functions */
#include "lwip/prot/dhcp.h"	/* dhcp constants */
#include "sys.h"			/* sys_now() */
#include "netif/ethernet.h"
#include "ethernetif.h"

#include "board.h"

#include "pin_mux.h"

#if defined(ENABLE_OM40006_ACCEL) && ENABLE_OM40006_ACCEL
#include "component/mma8652fc/fsl_mma.h"
#endif

#include "medium_one.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/

/* MAC address configuration. */
#define configMAC_ADDR                     \
    {                                      \
        0x02, 0x12, 0x13, 0x10, 0x15, 0x11 \
    }

/* Address of PHY interface. */
#define EXAMPLE_PHY_ADDRESS BOARD_ENET0_PHY_ADDRESS

/* System clock name. */
#define EXAMPLE_CLOCK_NAME kCLOCK_CoreSysClk

/* Application message publishing */
#define PUBLISH_ITERATIONS	-1 		/* number of periodic messages to publish, or -1 to publish forever */
#define PUBLISH_PERIOD_MS	10000	/* publishing interval in milliseconds */

/* User and ISP[0-2] buttons */
enum button_selector {
	USER_BTN = 0,
	ISP0_BTN,
	ISP1_BTN,
	ISP2_BTN
};

/*******************************************************************************
* Prototypes
******************************************************************************/

/*******************************************************************************
* Variables
******************************************************************************/

/* Network interface on OM40006 baseboard */
static struct netif fsl_netif0;

/* Callback flags */
static int dns_found = 0;
static int dns_failed = 0;
static int connected = 0;
static int connect_failed = 0;
static int published = 0;
static int publish_failed = 0;

#if defined(ENABLE_OM40006_ACCEL) && ENABLE_OM40006_ACCEL
/* Accelerometer on OM40006 */
static int accel_valid = 0;
static mma_handle_t accelHandle = {0};
static const uint8_t accelAddress[] = { 0x1DU };
static mma_config_t accelConfig = {0};
static uint8_t accelDataScale = 0;
static uint8_t accelResolution = 0;
static uint8_t accelDivider = 0;
#endif

/*******************************************************************************
 * Code
 ******************************************************************************/

/*!
 * @brief Interrupt service for SysTick timer.
 */
void SysTick_Handler(void)
{
    time_isr();
}

/* Initialize timeout tracking value */
static u32_t init_timeout(u32_t *timeval)
{
	return *timeval = sys_now();
}

/* Check for timeout condition */
static int check_timeout(u32_t *timeval, u32_t ms)
{
	if ((sys_now() - *timeval) > ms) {
		return 1;
	} else {
		return 0;
	}
}

/* Delay milliseconds */
static void delay_ms(u32_t ms)
{
	u32_t start = sys_now();
	while ((sys_now() - start) < ms) {
	}
}

/* Initialize LEDs on OM40006 baseboard */
static void BOARD_InitLEDs(void)
{
    GPIO_PortInit(BOARD_LED1_GPIO, BOARD_LED1_GPIO_PORT);
    GPIO_PortInit(BOARD_LED2_GPIO, BOARD_LED2_GPIO_PORT);
    LED1_INIT(LOGIC_LED_OFF);
    LED2_INIT(LOGIC_LED_OFF);
}

/* Initialize buttons on OM40006 baseboard */
static void BOARD_InitButtons(void)
{
    gpio_pin_config_t io_config = {
    	.pinDirection = kGPIO_DigitalInput
    };
    GPIO_PortInit(GPIO, 0);					// ISP[0-2] Button port
    GPIO_PortInit(GPIO, 1);					// User Button port
    GPIO_PinInit(GPIO, 1, 1, &io_config);	// User Button
    GPIO_PinInit(GPIO, 0, 4, &io_config);	// ISP0 Button
    GPIO_PinInit(GPIO, 0, 5, &io_config);	// ISP1 Button
    GPIO_PinInit(GPIO, 0, 6, &io_config);	// ISP2 Button
}

/* Read buttons on OM40006 baseboard */
static int BOARD_ReadButton(enum button_selector button)
{
	/* Return 1 is pressed, 0 if not pressed */
	/* No additional debouncing is done      */
	switch (button) {
		case USER_BTN:
			return GPIO_PinRead(GPIO, 1, 1) ^ 1;
		case ISP0_BTN:
			return GPIO_PinRead(GPIO, 0, 4) ^ 1;
		case ISP1_BTN:
			return GPIO_PinRead(GPIO, 0, 5) ^ 1;
		case ISP2_BTN:
			return GPIO_PinRead(GPIO, 0, 6) ^ 1;
		default:
			return 0;
			break;
	}
}

/* Run networking functions while waiting for events */
static void run_network(struct netif *network_interface)
{
	/* Poll the driver, get any outstanding frames */
	ethernetif_input(network_interface);

	/* Handle all system timeouts for all core protocols */
	sys_check_timeouts();
}

/* Initialize network interface */
static void BOARD_InitNetwork(void)
{
    ip4_addr_t fsl_netif0_ipaddr, fsl_netif0_netmask, fsl_netif0_gw;
    ethernetif_config_t fsl_enet_config0 = {
        .phyAddress = EXAMPLE_PHY_ADDRESS,
        .clockName = EXAMPLE_CLOCK_NAME,
        .macAddress = configMAC_ADDR,
    };

    /* Network */

    IP4_ADDR(&fsl_netif0_ipaddr, 0, 0, 0, 0);
    IP4_ADDR(&fsl_netif0_netmask, 0, 0, 0, 0);
    IP4_ADDR(&fsl_netif0_gw, 0, 0, 0, 0);

    lwip_init();

    netif_add(&fsl_netif0, &fsl_netif0_ipaddr, &fsl_netif0_netmask, &fsl_netif0_gw,
              &fsl_enet_config0, ethernetif0_init, ethernet_input);
    netif_set_default(&fsl_netif0);
    netif_set_up(&fsl_netif0);

    /* Get IP address using DHCP */

    PRINTF("Getting IP address from DHCP server\r\n");

    err_t err_dhcp;

    err_dhcp = dhcp_start(&fsl_netif0);

    if (err_dhcp == ERR_OK) {
    	PRINTF("DHCP started\r\n");
    } else {
    	PRINTF("ERROR: DHCP return code = %d = %s\r\n", err_dhcp, lwip_strerr(err_dhcp));
    }

    int timeout = 0;
    u32_t timeout_clock;
    init_timeout(&timeout_clock);

    LED1_ON();

    struct dhcp *dhcp = netif_get_client_data(&fsl_netif0, LWIP_NETIF_CLIENT_DATA_INDEX_DHCP);

    while (dhcp->state != DHCP_STATE_BOUND && !(timeout = check_timeout(&timeout_clock, 10000))) {
    	run_network(&fsl_netif0);
    }

    LED1_OFF();

    if (timeout) {
    	PRINTF("DHCP timed out\r\n");
    } else {
    	PRINTF("Obtained DHCP address\r\n");
    }
}

#if defined(ENABLE_OM40006_ACCEL) && ENABLE_OM40006_ACCEL
/* Initialize Accelerometer on OM40006 baseboard */
static void BOARD_InitAccel(void)
{
    CLOCK_AttachClk(kFRO12M_to_FLEXCOMM2);	// I2C clock
    BOARD_Accel_I2C_Init();
    u8_t sensorRange = 0;
    status_t accelResult = kStatus_Fail;
    accelConfig.I2C_SendFunc = BOARD_Accel_I2C_Send;
    accelConfig.I2C_ReceiveFunc = BOARD_Accel_I2C_Receive;
    for (int i = 0; i < sizeof(accelAddress) / sizeof(accelAddress[0]); i++) {
    	accelConfig.slaveAddress = accelAddress[i];
    	accelResult = MMA_Init(&accelHandle, &accelConfig);
    	if (accelResult == kStatus_Success) {
    		break;
    	}
    }
    if (accelResult != kStatus_Success) {
    	PRINTF("ERROR: Accelerometer initialization failed\r\n");
    	accel_valid = 0;
    } else {
    	accelResolution = MMA_GetResolutionBits();
    	accelDivider = (1 << (16 - accelResolution));
    	if (kStatus_Success == MMA_ReadReg(&accelHandle, kMMA8652_XYZ_DATA_CFG, &sensorRange)) {
    		if (sensorRange == 0x00) {
    			accelDataScale = 2;
    		} else if (sensorRange == 0x01) {
    			accelDataScale = 4;
    		} else if (sensorRange == 0x10) {
    			accelDataScale = 8;
    		}
    	}
    	accel_valid = 1;
    }
}

/* Read Accelerometer on OM40006 baseboard, return 1 if okay or 0 if failed */
static int BOARD_ReadAccel(int16_t *x_val, int16_t *y_val, int16_t *z_val)
{
	int result = 0;
	if (accel_valid) {
		mma_data_t sensorData = {0};
		if (kStatus_Success == MMA_ReadSensorData(&accelHandle, &sensorData)) {
			*x_val = (int16_t)((uint16_t)((uint16_t)sensorData.accelXMSB << 8) | (uint16_t)sensorData.accelXLSB) / accelDivider;
			*y_val = (int16_t)((uint16_t)((uint16_t)sensorData.accelYMSB << 8) | (uint16_t)sensorData.accelYLSB) / accelDivider;
			*z_val = (int16_t)((uint16_t)((uint16_t)sensorData.accelZMSB << 8) | (uint16_t)sensorData.accelZLSB) / accelDivider;
			result = 1;
		}
	}
	return result;
}
#endif

/* Callback when DNS query completed */
static void dns_found_cb(const char *name, const ip_addr_t *ipaddr, void *callback_arg)
{
	// PRINTF("DNS found callback\r\n");
	if (ipaddr == NULL) {
		PRINTF("Could not find IP address for: %s\r\n", name);
		dns_failed = 1;
	} else {
		PRINTF("Found IP address %s for: %s\r\n", ipaddr_ntoa(ipaddr), name);
		dns_found = 1;
	}
}

/* Perform DNS query, returns 1 if successful or 0 if failed */
static int Query_DNS(char *name, ip_addr_t *resolved_ip_addr)
{
	/* Use Google DNS server to get IP address for name */

	ip_addr_t dns_server_ip_addr;
    IP4_ADDR(&dns_server_ip_addr, 8, 8, 8, 8);	// google-public-dns-a.google.com
    dns_setserver(0, &dns_server_ip_addr);

    PRINTF("Doing DNS lookup on %s\r\n", name);

    dns_found = 0;
    dns_failed = 0;

    LED1_ON();

    /* First resolver call triggers DNS query to server */
    err_t err = dns_gethostbyname(name, resolved_ip_addr, dns_found_cb, NULL);

    int result = 1;

    switch (err) {
    	case ERR_OK:
    		// PRINTF("Name found\r\n");
    		break;
    	case ERR_INPROGRESS:
    		// PRINTF("DNS request queued\r\n");
    		break;
    	case ERR_VAL:
    		PRINTF("ERROR: Illegal parameter value\r\n");
    		result = 0;
    		break;
    	case ERR_ARG:
    		PRINTF("ERROR: DNS client not initialize or invalid hostname\r\n");
    		result = 0;
    		break;
    	default:
    		PRINTF("ERROR: %d\r\n", err);
    		result = 0;
    		break;
    }

    if (result == 1) {
		int timeout = 0;
		u32_t timeout_clock;
		init_timeout(&timeout_clock);

		while (!dns_found && !dns_failed && !(timeout = check_timeout(&timeout_clock, 7000))) {
			run_network(&fsl_netif0);
		}

		if (timeout) {
			PRINTF("ERROR: Timeout during DNS query\r\n");
			result = 0;
		} else {
			/* Second resolver call gets resolved address from cache */
			err = dns_gethostbyname(name, resolved_ip_addr, dns_found_cb, NULL);

			if (err == ERR_OK) {
				PRINTF("%s resolves to %s\r\n", name, ipaddr_ntoa(resolved_ip_addr));
				result = 1;
			} else {
				PRINTF("ERROR: Unable to find IP for %s\r\n", name);
				result = 0;
			}
		}
    }

    LED1_OFF();

	return result;
}


/* Convert u32 to ascii string */
char *u32toa(u32_t value)
{
	static char result[16];  // note this is static var
	char *p = result + sizeof(result) - 1;	// point to end of string buf
	*p-- = 0;
	do {
		*p-- = (value % 10) + 0x30;
		value /= 10;
	} while (value != 0);
	p++;       // point to start of converted digit string within result
	return p;
}

/* Convert i32 to ascii string */
char *i32toa(int32_t value)
{
	/* Assumes static buffer in u32toa() can also hold a minus sign on left end of result */
	char *p = u32toa(abs(value));
	if (value < 0) {
		*(--p) = '-';
	}
	return p;
}


/* Callback when MQTT connection is established */
static void mqtt_connection_cb(mqtt_client_t *client, void *arg, mqtt_connection_status_t status)
{
	PRINTF("MQTT Connection callback: ");
	switch (status) {
		case MQTT_CONNECT_ACCEPTED:
			PRINTF("MQTT_CONNECT_ACCEPTED");
			connected = 1;
			break;
		case MQTT_CONNECT_REFUSED_PROTOCOL_VERSION:
			PRINTF("MQTT_CONNECT_REFUSED_PROTOCOL_VERSION");
			connect_failed = 1;
			break;
		case MQTT_CONNECT_REFUSED_IDENTIFIER:
			PRINTF("MQTT_CONNECT_REFUSED_IDENTIFIER");
			connect_failed = 1;
			break;
		case MQTT_CONNECT_REFUSED_SERVER:
			PRINTF("MQTT_CONNECT_REFUSED_SERVER");
			connect_failed = 1;
			break;
		case MQTT_CONNECT_REFUSED_USERNAME_PASS:
			PRINTF("MQTT_CONNECT_REFUSED_USERNAME_PASS");
			connect_failed = 1;
			break;
		case MQTT_CONNECT_REFUSED_NOT_AUTHORIZED_:
			PRINTF("MQTT_CONNECT_REFUSED_NOT_AUTHORIZED_");
			connect_failed = 1;
			break;
		case MQTT_CONNECT_DISCONNECTED:
			PRINTF("MQTT_CONNECT_DISCONNECTED");
			connected = 0;
			break;
		case MQTT_CONNECT_TIMEOUT:
			PRINTF("MQTT_CONNECT_TIMEOUT");
			connect_failed = 1;
			break;
		default:
			PRINTF("%d status code unrecognized");
			connect_failed = 1;
			break;
	}
	PRINTF("\r\n");
}

/* Connect to MQTT broker, return 1 if successful or 0 if failed */
static int do_mqtt_connect(mqtt_client_t *client, ip_addr_t *broker_ip_addr)
{
    memset(client, 0, sizeof(mqtt_client_t));

    struct mqtt_connect_client_info_t ci;

    /* Set up an empty client info structure */
    memset(&ci, 0, sizeof(ci));

    /* Set up client info */
    ci.client_id = MQTT_CLIENT_ID;
    ci.client_user = MQTT_USERNAME;
    ci.client_pass = MQTT_PASSWORD;
    ci.keep_alive = 60;

    /* Initiate client and connect to server, if this fails immediately an error code is returned
       otherwise mqtt_connection_cb will be called with connection result after attempting
       to establish a connection with the server.
       For now MQTT version 3.1.1 is always used */

    PRINTF("Connecting to MQTT broker\r\n");

    connected = 0;
    connect_failed = 0;

    LED1_ON();

    err_t err = mqtt_client_connect(client, broker_ip_addr, MQTT_PORT_NON_TLS, mqtt_connection_cb, 0, &ci);

    int result = 1;

    if (err == ERR_OK) {
    	PRINTF("Waiting for connect callback\r\n");
    } else if (err == ERR_ISCONN) {
    	PRINTF("Already connected\r\n");
    	connected = 1;
    } else {
      PRINTF("ERROR: Connect failed, return code = %d = %s\n", err, lwip_strerr(err));
      result = 0;
    }

    if (result == 1) {

		/* Wait until connect callback has been called, or fall through if already connected */

		int timeout = 0;
		u32_t timeout_clock;
		init_timeout(&timeout_clock);

		while (!connected && !connect_failed && !(timeout = check_timeout(&timeout_clock, 5000))) {
			run_network(&fsl_netif0);
		}

		if (timeout) {
			PRINTF("ERROR: Timeout while waiting for connect callback\r\n");
			result = 0;
		}
    }

    LED1_OFF();

	return result;
}

/* Disconnect from MQTT broker, return 1 if successful or 0 if failed */
static int do_mqtt_disconnect(mqtt_client_t *client)
{
	int result = 1;

	if (mqtt_client_is_connected(client)) {

		/* Disconnect from broker */

		PRINTF("Disconnecting from MQTT broker\r\n");

		LED1_ON();

		mqtt_disconnect(client);

		int timeout = 0;
		u32_t timeout_clock;
		init_timeout(&timeout_clock);

		do {
			run_network(&fsl_netif0);
		} while (mqtt_client_is_connected(client) && !(timeout = check_timeout(&timeout_clock, 10000)));

		if (timeout) {
			PRINTF("ERROR: Timeout during disconnect\r\n");
			result = 0;
		} else {
			PRINTF("Disconnect complete\r\n");
		}

		LED1_OFF();

	} else {
		PRINTF("Client is not connected, skipping disconnect\r\n");
	}

	return result;
}

/* Callback when MQTT publish is complete with success or failure */
static void mqtt_pub_request_cb(void *arg, err_t result)
{
	if (result == ERR_OK) {
		PRINTF("Publish Callback successful\r\n");
		published = 1;
	} else {
		PRINTF("ERROR: Publish Callback return code = %d = %s\r\n", result, lwip_strerr(result));
		publish_failed = 1;
	}
}

/* Publish MQTT message to broker, return 1 if successful or 0 if failed */
static int do_mqtt_publish(mqtt_client_t *client, char *topic, char *payload, u8_t qos, u8_t retain)
{
	int result = 1;

	PRINTF("Publishing message: %s\r\n", payload);

	published = 0;
	publish_failed = 0;

	LED1_ON();

	err_t err = mqtt_publish(client, topic, payload, strlen(payload), qos, retain, mqtt_pub_request_cb, NULL);

	if (err == ERR_OK) {
		PRINTF("Waiting for publish callback\r\n");
	} else if (err == ERR_MEM) {
		PRINTF("ERROR: Publish failed, out of memory (ERR_MEM)\r\n");
		result = 0;
	} else {
		PRINTF("ERROR: Publish failed, return code = %d = %s\r\n", lwip_strerr(err));
		result = 0;
	}

	if (result == 1) {

		/* Wait until publish callback has been called */

		int timeout = 0;
		u32_t timeout_clock;
		init_timeout(&timeout_clock);

		while (!published && !publish_failed && !(timeout = check_timeout(&timeout_clock, 5000))) {
			run_network(&fsl_netif0);
		}

		if (timeout) {
			PRINTF("ERROR: Timeout while waiting for publish callback\r\n");
			result = 0;
		}
	}

	LED1_OFF();

	return result;
}

/*!
 * @brief Main function.
 */
int main(void)
{
    CLOCK_EnableClock(kCLOCK_InputMux);

    /* Attach 12 MHz clock to FLEXCOMM0 (debug console) */
    CLOCK_AttachClk(BOARD_DEBUG_UART_CLK_ATTACH);

    BOARD_InitPins();
    BOARD_BootClockFROHF96M();
    BOARD_InitDebugConsole();

    /* Initialize timer clock */

    time_init();

    /* Initialize User LEDs & User Button on OM40006 baseboard */

    BOARD_InitLEDs();

    LED1_ON();
    delay_ms(500);
    LED2_ON();
    delay_ms(500);
    LED1_OFF();
    delay_ms(500);
    LED2_OFF();

    BOARD_InitButtons();

#if defined(ENABLE_OM40006_ACCEL) && ENABLE_OM40006_ACCEL

    /* Initialize MMA8652 Accelerometer on OM40006 baseboard */

    BOARD_InitAccel();

#endif

    /* Initialize Ethernet on OM40006 baseboard */

    BOARD_InitNetwork();

    PRINTF("IPv4 Address     : %s\r\n", ipaddr_ntoa(&fsl_netif0.ip_addr));
    PRINTF("IPv4 Subnet mask : %s\r\n", ipaddr_ntoa(&fsl_netif0.netmask));
    PRINTF("IPv4 Gateway     : %s\r\n", ipaddr_ntoa(&fsl_netif0.gw));

	/* Resolve address of MQTT broker */

	ip_addr_t broker_ip_addr;

    while (Query_DNS(MQTT_BROKER, &broker_ip_addr) == 0) {
			PRINTF("DNS lookup failed, retrying\r\n");
    }

    mqtt_client_t client;

    /* Main loop */

    while (1) {

		/* Connect to MQTT broker */

		while (do_mqtt_connect(&client, &broker_ip_addr) == 0) {
			PRINTF("MQTT connect failed, retrying\r\n");

		}

		/* Publish a set of periodic messages */

		char payload[132];				// mqtt payload string
		u32_t start_time;				// transmission period timer
		int iteration_count = 0;		// current iteration count
		int button_state = 0;
		int button_last_state = 0;

#if defined(ENABLE_OM40006_ACCEL) && ENABLE_OM40006_ACCEL
		int16_t x_accel, y_accel, z_accel;
#endif

		/* Publish loop */

		while (PUBLISH_ITERATIONS == -1 || iteration_count < PUBLISH_ITERATIONS) {

			iteration_count++;

			if (BOARD_ReadButton(ISP2_BTN)) {
				/* Pressing ISP2 button terminates transmission loop */
				PRINTF("Detected ISP2 button, terminating transmission loop\r\n");
				break;
			}

			init_timeout(&start_time);

			/* Publish a new message */

			/*
			 * Message format:
			 *
			 *      {"event_data":{"device":"lpc54018","iteration":1,"clock":1234,"button":0}
			 *
			 * If accelerometer is enabled the following additional
			 * fields will be included in the message:
			 *
			 *       "x":123,"y":123,"z":123
			 *
			 * Use of sprintf() is avoided.
			 */

			strcpy(payload, "{\"event_data\":{\"device\":\"lpc54018\",\"iteration\":");
			strcat(payload, u32toa(iteration_count));
			strcat(payload, ",\"clock\":");
			strcat(payload, u32toa(start_time));
			strcat(payload, ",\"button\":");
			if (button_last_state) {
				strcat(payload, "true");
			} else {
				strcat(payload, "false");
			}

#if defined(ENABLE_OM40006_ACCEL) && ENABLE_OM40006_ACCEL
			/* If accelerometer is enabled, read it and add to payload */
			if (BOARD_ReadAccel(&x_accel, &y_accel, &z_accel)) {
				strcat(payload, ",\"x\":");
				strcat(payload, i32toa(x_accel));
				strcat(payload, ",\"y\":");
				strcat(payload, i32toa(y_accel));
				strcat(payload, ",\"z\":");
				strcat(payload, i32toa(z_accel));
			}
#endif

			strcat(payload, "}}");

			if (do_mqtt_publish(&client, MQTT_TOPIC, payload, 0, 0) == 1) {
				PRINTF("Publish successful\r\n");
			} else {
				PRINTF("Publish failed\r\n");
			}

			if (PUBLISH_ITERATIONS == -1 || iteration_count < PUBLISH_ITERATIONS) {
				/* Wait until next period */
				PRINTF("Waiting until end of publish interval\r\n");
				while (!check_timeout(&start_time, PUBLISH_PERIOD_MS)) {
					run_network(&fsl_netif0);
					/* Pressing button immediately jumps to next period */
					button_state = BOARD_ReadButton(USER_BTN); // user_btn_pressed();
					if (button_state != button_last_state) {
						if (button_state == 1) {
							PRINTF("User button pressed, jumping to next period\r\n");
							button_last_state = button_state;
							break;
						} else {
							button_last_state = button_state;
						}
					}
					/* Pressing ISP2 button terminates transmission loop */
					if (BOARD_ReadButton(ISP2_BTN) /*isp_btn_pressed(ISP2_BTN)*/) {
						break;
					}
				}
			}
		}

		/* Disconnect from MQTT broker */

		do_mqtt_disconnect(&client);

		/* Wait for User button pressed, then restart the connect/transmit/disconnect cycle */

		PRINTF("*** Waiting for User button press to restart transmission loop ***\r\n");

		u32_t last_clock = sys_now();

		while (!BOARD_ReadButton(USER_BTN)) {
			run_network(&fsl_netif0);
			/* Flash User LED2 while waiting for button press */
			if ((sys_now() - last_clock) >= 100) {
				LED2_TOGGLE();
				last_clock = sys_now();
			}
		}

		LED2_OFF();

		PRINTF("*** Restarting transmission loop ***\r\n");

    }

    return 0;

}
#endif
